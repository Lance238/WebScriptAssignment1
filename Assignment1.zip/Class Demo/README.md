Works Cited

- SQL Logo Picture: https://commons.wikimedia.org/wiki/File:Sql_data_base_with_logo.png
- Video used in about me page: https://www.youtube.com/watch?v=q0INEorhinw (Ichika Nito)
- Code for footer: https://dev.to/nehalahmadkhan/how-to-make-footer-stick-to-bottom-of-web-page-3i14 (Nehal Ahmad)
- Active button: https://www.w3schools.com/cssref/sel_active.asp
- Linear gradient: https://developer.mozilla.org/en-US/docs/Web/CSS/gradient/linear-gradient
- Telephone number format: https://www.w3schools.com/tags/att_input_type_tel.asp
